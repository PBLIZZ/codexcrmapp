
import { GoogleGenAI, GenerateContentResponse } from '@google/genai';
import { GEMINI_MODEL_NAME } from '../constants';

const API_KEY = process.env.API_KEY;

let ai: GoogleGenAI | null = null;

if (API_KEY) {
  try {
    ai = new GoogleGenAI({ apiKey: API_KEY });
  } catch (error) {
    console.error("Failed to initialize GoogleGenAI:", error);
    // ai remains null, isApiKeySet will return false
  }
}


export const isApiKeySet = (): boolean => !!ai && !!API_KEY;

export const reviewCode = async (code: string, language: string): Promise<string> => {
  if (!isApiKeySet() || !ai) {
    // This error message is more user-friendly for the UI
    throw new Error('Gemini API key not configured or invalid. Please ensure the API_KEY environment variable is correctly set.');
  }

  const prompt = `
You are an expert AI code reviewer. Your task is to analyze the provided code snippet written in ${language}.
Please provide a comprehensive and constructive review. Focus on the following aspects:

1.  **Bugs and Potential Errors:**
    *   Identify any logical flaws, runtime errors, off-by-one errors, or unhandled edge cases.
    *   Point out potential null pointer exceptions or type errors.

2.  **Best Practices & Conventions:**
    *   Evaluate adherence to ${language} idiomatic code, best practices, and common coding standards/style guides.
    *   Comment on naming conventions for variables, functions, classes, etc.

3.  **Performance:**
    *   Identify any obvious performance bottlenecks (e.g., inefficient algorithms, unnecessary computations in loops).
    *   Suggest potential optimizations if applicable.

4.  **Security Vulnerabilities:**
    *   (If applicable to the language/context, e.g., web languages, SQL)
    *   Highlight potential security risks like XSS, SQL injection, insecure handling of secrets, etc.

5.  **Readability & Maintainability:**
    *   Assess code clarity, organization, and structure.
    *   Comment on the use of comments (too few, too many, unclear).
    *   Suggest ways to improve code modularity and reduce complexity.

6.  **Suggestions for Improvement & Refactoring:**
    *   Offer concrete, actionable suggestions for improving the code.
    *   If appropriate, provide small, corrected code snippets to illustrate your points.

**Output Format:**
Structure your feedback clearly. Use Markdown for formatting:
*   Use headings (e.g., \`## Bugs and Potential Errors\`) for major sections.
*   Use bullet points (\`*\` or \`-\`) for listing items.
*   Use fenced code blocks (e.g., \`\`\`${language}\\ncode here\\n\`\`\`) for all code examples or references.

**Code to Review:**
\`\`\`${language}
${code}
\`\`\`
`;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_MODEL_NAME,
      contents: prompt,
      config: {
        // temperature: 0.7, // A balanced temperature for creative but factual review
        // topK: 40,
        // topP: 0.95,
      }
    });
    return response.text;
  } catch (error) {
    console.error('Error calling Gemini API:', error);
    if (error instanceof Error) {
        const specificError = error as any;
        let errorMessage = `Gemini API error: ${specificError.message || 'An unknown API error occurred.'}`;
        if (specificError.message && specificError.message.toLowerCase().includes('api key not valid')) {
          errorMessage = 'Invalid Gemini API Key. Please check your API_KEY environment variable.';
        } else if (specificError.message && (specificError.message.toLowerCase().includes('quota') || specificError.message.toLowerCase().includes('rate limit'))) {
          errorMessage = 'API request limit reached or quota exceeded. Please try again later or check your Gemini API quota.';
        } else if (specificError.status === 400) {
           errorMessage = `Gemini API Bad Request (400): The request was malformed. Details: ${specificError.message}`;
        }
        // Add more specific error checks if needed based on Gemini SDK error types
        throw new Error(errorMessage);
    }
    throw new Error('Failed to get review from Gemini API. An unknown error occurred.');
  }
};
