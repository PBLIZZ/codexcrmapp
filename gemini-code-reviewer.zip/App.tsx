
import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { CodeInputArea } from './components/CodeInputArea';
import { FeedbackDisplayArea } from './components/FeedbackDisplayArea';
import { ApiKeyMissingMessage } from './components/ApiKeyMissingMessage';
import { ErrorMessage } from './components/ErrorMessage';
import { LoadingSpinner } from './components/LoadingSpinner';
import { reviewCode, isApiKeySet } from './services/geminiService';
import { DEFAULT_LANGUAGE, SUPPORTED_LANGUAGES } from './constants';
import type { LanguageOption } from './constants';

const App: React.FC = () => {
  const [apiKeyFound, setApiKeyFound] = useState<boolean | null>(null);
  const [code, setCode] = useState<string>('');
  const [language, setLanguage] = useState<string>(DEFAULT_LANGUAGE);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setApiKeyFound(isApiKeySet());
  }, []);

  const handleSubmitReview = useCallback(async () => {
    if (!code.trim()) {
      setError('Please enter some code to review.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setFeedback(null);
    try {
      const result = await reviewCode(code, language);
      setFeedback(result);
    } catch (err) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError('An unknown error occurred during review.');
      }
    } finally {
      setIsLoading(false);
    }
  }, [code, language]);

  if (apiKeyFound === null) {
    return (
      <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col items-center justify-center">
        <LoadingSpinner size="large" />
        <p className="mt-4 text-lg">Checking API configuration...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col">
      <Header />
      <main className="flex-grow container mx-auto p-4 sm:p-6 lg:p-8 flex flex-col">
        {!apiKeyFound ? (
          <ApiKeyMissingMessage />
        ) : (
          <>
            {error && <ErrorMessage message={error} onClose={() => setError(null)} />}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 flex-grow min-h-0">
              <div className="flex flex-col min-h-[400px] lg:min-h-0 lg:h-full">
                <CodeInputArea
                  code={code}
                  onCodeChange={setCode}
                  language={language}
                  onLanguageChange={setLanguage}
                  supportedLanguages={SUPPORTED_LANGUAGES}
                  onSubmit={handleSubmitReview}
                  isLoading={isLoading}
                  currentLanguageLabel={SUPPORTED_LANGUAGES.find(l => l.value === language)?.label || language}
                />
              </div>
              <div className="flex flex-col min-h-[400px] lg:min-h-0 lg:h-full">
                <FeedbackDisplayArea feedback={feedback} isLoading={isLoading} />
              </div>
            </div>
          </>
        )}
      </main>
      <Footer />
    </div>
  );
};

export default App;
