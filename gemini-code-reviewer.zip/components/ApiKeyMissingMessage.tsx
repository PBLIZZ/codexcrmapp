
import React from 'react';

export const ApiKeyMissingMessage: React.FC = () => {
  return (
    <div className="bg-red-900 border-l-4 border-red-500 text-red-100 p-6 rounded-md shadow-lg my-auto" role="alert">
      <div className="flex">
        <div className="py-1">
          <svg className="fill-current h-6 w-6 text-red-400 mr-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
            <path d="M2.93 17.07A10 10 0 1 1 17.07 2.93 10 10 0 0 1 2.93 17.07zM9 5v6h2V5H9zm0 8v2h2v-2H9z"/>
          </svg>
        </div>
        <div>
          <p className="font-bold text-xl mb-2">API Key Configuration Error</p>
          <p className="text-md">
            The Gemini API key is not configured. This application requires the <code>API_KEY</code> environment variable to be set for connecting to the Google Gemini API.
          </p>
          <p className="mt-3 text-sm">
            Please ensure that <code>process.env.API_KEY</code> is available in your application's environment.
            You might need to configure this in your <code>.env</code> file (if using a tool like Vite or Create React App that supports it for development) or set it directly in your deployment environment.
          </p>
        </div>
      </div>
    </div>
  );
};
