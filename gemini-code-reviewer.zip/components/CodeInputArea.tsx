
import React from 'react';
import type { LanguageOption } from '../constants';
import { LoadingSpinner } from './LoadingSpinner';

interface CodeInputAreaProps {
  code: string;
  onCodeChange: (newCode: string) => void;
  language: string;
  onLanguageChange: (newLanguage: string) => void;
  supportedLanguages: LanguageOption[];
  onSubmit: () => void;
  isLoading: boolean;
  currentLanguageLabel: string;
}

export const CodeInputArea: React.FC<CodeInputAreaProps> = ({
  code,
  onCodeChange,
  language,
  onLanguageChange,
  supportedLanguages,
  onSubmit,
  isLoading,
  currentLanguageLabel
}) => {
  return (
    <div className="bg-slate-800 p-4 sm:p-6 rounded-lg shadow-xl flex flex-col h-full">
      <h2 className="text-xl font-semibold text-sky-400 mb-4">Enter Your Code</h2>
      
      <div className="mb-4">
        <label htmlFor="language-select" className="block text-sm font-medium text-slate-300 mb-1">
          Programming Language
        </label>
        <select
          id="language-select"
          value={language}
          onChange={(e) => onLanguageChange(e.target.value)}
          className="bg-slate-700 border border-slate-600 text-slate-100 rounded-md p-2.5 focus:ring-2 focus:ring-sky-500 focus:border-sky-500 w-full transition-colors duration-150"
          disabled={isLoading}
        >
          {supportedLanguages.map(lang => (
            <option key={lang.value} value={lang.value}>{lang.label}</option>
          ))}
        </select>
      </div>

      <div className="flex-grow flex flex-col mb-4 min-h-[200px] sm:min-h-[300px]">
        <label htmlFor="code-input" className="block text-sm font-medium text-slate-300 mb-1">
          Code ({currentLanguageLabel})
        </label>
        <textarea
          id="code-input"
          value={code}
          onChange={(e) => onCodeChange(e.target.value)}
          placeholder={`Paste your ${currentLanguageLabel.toLowerCase()} code here...`}
          className="w-full flex-grow bg-slate-900 border border-slate-700 rounded-md p-3 font-mono text-sm text-slate-200 resize-y focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition-colors duration-150"
          disabled={isLoading}
          spellCheck="false"
        />
      </div>

      <button
        type="button"
        onClick={onSubmit}
        disabled={isLoading || !code.trim()}
        className="w-full bg-sky-600 hover:bg-sky-700 disabled:bg-slate-600 disabled:cursor-not-allowed text-white font-semibold py-3 px-4 rounded-md transition duration-150 ease-in-out flex items-center justify-center text-base"
      >
        {isLoading ? (
          <>
            <LoadingSpinner size="small" />
            <span className="ml-2">Reviewing...</span>
          </>
        ) : (
          'Review Code ✨'
        )}
      </button>
    </div>
  );
};
