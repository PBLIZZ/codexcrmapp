
import React, { useState, useEffect } from 'react';
import { LoadingSpinner } from './LoadingSpinner';

interface FeedbackDisplayAreaProps {
  feedback: string | null;
  isLoading: boolean;
}

export const FeedbackDisplayArea: React.FC<FeedbackDisplayAreaProps> = ({ feedback, isLoading }) => {
  const [copied, setCopied] = useState(false);

  const handleCopyFeedback = async () => {
    if (feedback) {
      try {
        await navigator.clipboard.writeText(feedback);
        setCopied(true);
      } catch (err) {
        console.error('Failed to copy feedback: ', err);
        alert('Failed to copy feedback. Please try again or copy manually.');
      }
    }
  };

  useEffect(() => {
    if (copied) {
      const timer = setTimeout(() => setCopied(false), 2000);
      return () => clearTimeout(timer);
    }
  }, [copied]);
  
  useEffect(() => {
    // Reset copied state when feedback changes
    setCopied(false);
  }, [feedback]);

  return (
    <div className="bg-slate-800 p-4 sm:p-6 rounded-lg shadow-xl flex flex-col h-full">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold text-sky-400">Review Feedback</h2>
        {feedback && !isLoading && (
          <button
            onClick={handleCopyFeedback}
            className={`bg-slate-700 hover:bg-slate-600 text-sky-300 font-medium py-1.5 px-3 rounded-md text-sm transition-all duration-150 ${
              copied ? 'bg-green-600 hover:bg-green-700 text-white' : ''
            }`}
            title={copied ? "Copied!" : "Copy feedback"}
          >
            {copied ? 'Copied ✓' : 'Copy'}
          </button>
        )}
      </div>
      <div className="flex-grow bg-slate-900 border border-slate-700 rounded-md p-3 overflow-y-auto min-h-[200px] sm:min-h-[300px]">
        {isLoading ? (
          <div className="flex flex-col items-center justify-center h-full text-slate-400">
            <LoadingSpinner size="large" />
            <p className="mt-4 text-lg">Generating feedback...</p>
          </div>
        ) : feedback ? (
          <pre className="whitespace-pre-wrap text-slate-300 text-sm font-mono leading-relaxed">
            {feedback}
          </pre>
        ) : (
          <p className="text-slate-400 italic text-center py-10">
            Your code review feedback will appear here once you submit code for review.
          </p>
        )}
      </div>
    </div>
  );
};
