
import React from 'react';

export const Header: React.FC = () => {
  return (
    <header className="bg-slate-800 shadow-md">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center">
        <span className="text-3xl mr-3">🤖</span>
        <h1 className="text-2xl font-bold text-sky-400">
          Gemini Code Reviewer
        </h1>
      </div>
    </header>
  );
};
