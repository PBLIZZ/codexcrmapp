
import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-800 mt-auto">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4 text-center text-sm text-slate-400">
        <p>&copy; {new Date().getFullYear()} Gemini Code Reviewer. Powered by Google Gemini.</p>
      </div>
    </footer>
  );
};
