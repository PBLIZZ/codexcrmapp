
// Currently, most types are simple or defined alongside their use (e.g., in constants.ts).
// This file can be expanded as the application grows.

// Example: If Gemini API returns a structured object for feedback
// export interface StructuredFeedback {
//   clarity: number;
//   suggestions: string[];
//   issues: Array<{
//     line: number;
//     message: string;
//     severity: 'low' | 'medium' | 'high';
//   }>;
// }

// For now, feedback is a string.
export type ReviewFeedback = string;
